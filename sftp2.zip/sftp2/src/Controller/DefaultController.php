<?php

namespace App\Controller;

use App\Entity\Produit;
use App\Form\AjoutProduitType;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class DefaultController extends AbstractController
{
    /**
     * @Route("/", name="homepage")
     */
    public function index(): Response
    {
        $produit = $this->getDoctrine()->getRepository(Produit::class)->findAll();
        return $this->render('default/index.html.twig', [
            'produit' => $produit,
        ]);
    }
    /**
     * @Route("/ajoutProduit", name="ajoutProduit")
     */
    public function ajoutProduit(Request $request) {
        $produit = new Produit();
        $form = $this->createForm(AjoutProduitType::class,$produit);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($produit);
            $em->flush();
            return $this->redirectToRoute('homepage');
        }
        return $this->render('default/exo3.html.twig', ['form' => $form->createView()]);
    }

}
